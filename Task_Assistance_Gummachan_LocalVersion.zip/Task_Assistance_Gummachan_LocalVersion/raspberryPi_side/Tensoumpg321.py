#ラズパイの起動時に実行できるように設定する
import subprocess
import os
import time

#ラズパイ側に音声ファイルが来るまで無限ループ
while True:
    file=os.path.exists('Tensou.mp3のディレクトリ名/Tensou.mp3')
    #ファイルが存在したらmp3ファイルを鳴らすコマンドを実行し、その後Tensou.mp3を削除する
    if (file==True):
        subprocess.call("mpg321 Tensou.mp3のディレクトリ名/Tensou.mp3",shell='true')
        os.remove('Tensou.mp3のディレクトリ名/Tensou.mp3') #音声がなり続けないように削除する
    time.sleep(1)
