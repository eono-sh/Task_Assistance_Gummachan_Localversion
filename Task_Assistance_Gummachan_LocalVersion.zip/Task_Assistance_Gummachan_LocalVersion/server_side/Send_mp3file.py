#ラズパイのユーザ名はデフォルトを使用しています

import paramiko
from paramiko import SSHClient, AutoAddPolicy

#ラズパイに接続
def Send_mp3file(mp3file):
    host='ラズパイのローカルIPアドレス'    #ここは環境に応じて変更する
    host_username='ユーザ名'
    host_password='パスワード'

    client=paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=host, username=host_username, password=host_password,timeout=10, look_for_keys=False)

    try:
        sftp_connection = client.open_sftp()
        sftp_connection.put(mp3file, '/home/pi/Tensou.mp3.tmp')
        sftp_connection.rename('/home/pi/Tensou.mp3.tmp', '/home/pi/Tensou.mp3')

    finally:
        client.close()
